import numpy as np
import os
import sys
from constant import *
from func import *


scale = 'cm1'

if os.path.exists('./ph.fc') is not True :
    print("ERROR: We need ph.fc !!!")
    exit(0)
k = open('./ph.fc')
fi = k.readline().split()
ntyp = int(fi[0])
nat = int(fi[1])
celldm1 = float(fi[3])
A = np.zeros([3,3])
for i in range(3):
    ll = k.readline().split()
    for j in range(3):
        A[i][j] = ll[j]
mass_type = np.zeros([ntyp,2],dtype=object)
Atom_Mass = np.zeros(nat)
tau = np.zeros([nat,3])
for i in range(ntyp):
    ll = k.readline().split()
    mass_type[i,0] = ll[0]
    mass_type[i,1] = ll[1].split("'")[1]
for n in range(len(atom_data)):
    for i in range(ntyp):
        if atom_data[n][1] == mass_type[i,1]:
            mass_type[i,1] = atom_data[n][3]
for i in range(nat):
    ll = k.readline().split()
    for j in range(ntyp):
        if float(ll[1]) == float(mass_type[j][0]):
            Atom_Mass[i] = mass_type[j,1]
    tau[i,:] = np.array([float(val) for val in ll[2:5]])
epsil = k.readline().split()
k.close()

epsilon = np.zeros([3,3])
zstar = np.zeros([nat,3,3])
nac = 0
if len(sys.argv) > 1:
    if sys.argv[1] == '1':
        if epsil[0] == "T":
            print('If you want to add NAC, please remove the dielectric constant and Born effective charges data from the Gamma point dyn file and run q2r.x again to get correct ph.fc!!!')
            exit()
        else:
            if os.path.exists('./allborn') is not True :
                print("TO-LO splitting at q=0 will be absent!!!")
            else:
                nac = 1
                allborn = open('./allborn')
                for i in range(3):
                    epsilon[i,:] = allborn.readline().split()
                for i in range(nat):
                    allborn.readline()
                    zstar[i,0,:] = allborn.readline().split()
                    zstar[i,1,:] = allborn.readline().split()
                    zstar[i,2,:] = allborn.readline().split()
                allborn.close()
B = np.transpose(np.linalg.inv(A))

drec_k, rec_k, num_hsym = read_kpts('qe.kpts',B)
cellvolume = CellVolume(A,celldm1)

HmnR, irvec, ndegen = get_hr('phhr.dat',scale)
if nac == 1:
    mapvec, N_hrmap, SizeofSc = get_hrmap() 
else:
    mapvec, N_hrmap, SizeofSc = 0,0,0
omega=hk_ph(scale, HmnR, irvec, ndegen, nac, rec_k, nat, Atom_Mass, epsilon, zstar, A, cellvolume, mapvec, N_hrmap, SizeofSc)

f=open('./freq','w')
for i in range(len(rec_k)):
    print('{:10.6f}   '.format(drec_k[i]),end='',file=f)
    for j in range(3*nat):
        print('{:10.4f}'.format(omega[i,j]),end='' ,file=f)
    print(end='\n',file=f)
f.close()





