import numpy as np
from numpy.linalg import *
import os
from datetime import datetime


def mode():
    if os.path.exists('./ph.fc') is not True or os.path.exists('./matdyn.inp') is not True:
        print("ERROR: We need ph.fc & matdyn.inp !!!")
    else:
        if os.path.exists('./matdyn.modes') is not True:
            print("ERROR: We need matdyn.modes !!!")
            exit(0)

        f1 = open('./ph.fc')
        fcdata = f1.readline().split()
        fcnat = int(fcdata[1])
        f1.close()

        f2 = open('./matdyn.inp')
        lines = f2.readlines()
        for i in range(len(lines)):
            if '/' in lines[i]:
                kps = int(lines[i+1])
                kpn = i+1
        nq = 0
        for i in range(kps-1):
            nq += int(lines[kpn+i+1].split()[3])
        nq += 1
        f2.close()


        eqmode = 3*fcnat*(fcnat+1)+5             # modelines = eqmode * nq  # num of mode lines

        u = np.zeros([nq,3*fcnat,6*fcnat])
        fr = np.zeros([nq,3*fcnat,1])
        f3 = open('./matdyn.modes')
        mlines = f3.readlines()
        f3.close()
        
        pfile = open('./modes.dat','w')
        for i in range(nq):
            for j in range(3*fcnat):
                fr[i][j][0] = float(mlines[eqmode*i+4+j*(fcnat+1)].split("=")[2].split()[0])
                for k in range(fcnat):
                    for l in range(6):
                            u[i][j][k*6+l] = float(mlines[eqmode*i+5+j*(fcnat+1)+k].split()[l+1])
       
            
        print('{:8d}{:8d}{:8d}'.format(nq,3*fcnat,3*fcnat),file=pfile)
        for i in range(nq):
            for j in range(3*fcnat):
                print('{:13.6f}'.format(fr[i][j][0]),file=pfile)
                
                for kk in range((3*fcnat)//5):
                    xxx = (kk+1)*5
                    for kkk in range(xxx-5, xxx):
                        print("{:12.6f}{:12.6f}".format(u[i][j][2*kkk],u[i][j][2*kkk+1]), end='',file=pfile)
                    print(' ',file=pfile)
                if 3*fcnat % 5 > 0:
                    for k in range(xxx, xxx+(3*fcnat)%5):
                        print("{:12.6f}{:12.6f}".format(u[i][j][2*k],u[i][j][2*k+1]), end='',file=pfile)
                    print(' ',file=pfile)
        pfile.close()
        f4 = open('./lda_hr.dat','w')
        line=" Generated on "+str(datetime.now())+"\n"
        f4.write(line)
        f4.write('{:8d}\n'.format(3*fcnat))
        f4.write('{:8d}\n'.format(1))
        f4.write('{:8d}\n'.format(1))
        for i in range(1,3*fcnat+1):
            for j in range(1,3*fcnat+1):
                f4.write('{:8d}{:8d}{:8d}{:8d}{:8d}{:20.10f}{:20.10f}\n'.format(0,0,0,j,i,0,0))
        f4.close()
        print("modes.dat & lda_hr.dat are created successfully !!!")

     

mode()

