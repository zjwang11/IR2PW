import numpy as np
import os
import sys
from constant import *

def set_simple_asr(hop,nat,ntot):
    for i in range(3):
        for j in range(3):
            for na in range(nat):
                sumh = 0
                for nb in range(nat):
                    for n in range(ntot):
                        sumh += hop[n+(ntot*nb)+(ntot*nat*na)+(ntot*nat*nat*j)+(ntot*nat*nat*3*i)]
                hop[0+(ntot*na)+(ntot*nat*na)+(ntot*nat*nat*j)+(ntot*nat*nat*3*i)] -= sumh          
    return hop

def set_permutation_symmetry(hop,nat,ntot):
    hop_ = hop.copy()
    hop_hermite = hop.copy()
    for x1 in range(3):
        for x2 in range(3):
            for x1_ in range(3):
                for x2_ in range(3):
                    if x1 == x2_ and x2 == x1_ :
                        for i in range(nat):
                            for j in range(nat):
                                for i_ in range(nat):
                                    for j_ in range(nat):
                                        if i == j_ and j == i_ :
                                            ori = ntot*(j+nat*(i+nat*(x2+3*x1)))
                                            orit = ntot*(i+nat*(j+nat*(x1+3*x2)))
                                            for sc in range(ntot):
                                                hop_hermite[sc+ori] = (hop[sc+ori]+hop_[sc+orit])/2.0
    return hop_hermite



def CellVolume(A, celldm1):
    #cellvolume1 = np.dot(A[0], np.cross(A[1], A[2])) * (float(celldm1)*BOHR_ANG)**3
    cellvolume2 = np.linalg.det(A) * (celldm1*BOHR_ANG)**3
    return cellvolume2


def read_kpts(kpts_name,B):
    if os.path.exists('./{}'.format(kpts_name)) is not True :
        print("ERROR: We need qe.kpts !!!")
        exit(0)
    else:
        print("ONLY allow: q_in_band_form=.true. &  q_in_cryst_coord=.true. !!!")
    
    kpts = open('./{}'.format(kpts_name))
    num_hsym = int(kpts.readline().split()[0])
    hsym_p = np.zeros([num_hsym,4])
    for i in range(num_hsym):
        hsym_p[i,:] = kpts.readline().split()[:]
        hsym_p[i,0:3] = np.dot(hsym_p[i,0:3],B)
    kpts.close()
    hsym_p[-1,3] = 1
    nk = sum(hsym_p[:,3])
    rec_k = np.zeros([int(nk),3])
    drec_k = np.zeros([int(nk)])
    tmp = 0
    tmp1 = 0
    for i in range(num_hsym):
        if i < num_hsym-1 :
            diff = hsym_p[i+1,0:3] - hsym_p[i,0:3]
        else:
            diff = np.zeros([1,3])
        for j in range(int(hsym_p[i,3])):
            rec_k[tmp,:] = hsym_p[i,0:3] + diff * j / hsym_p[i,3]      ##klist(a,b,c)
            drec_k[tmp] = tmp1         ##kpath
            tmp1 += np.linalg.norm(diff / hsym_p[i,3] ) 
            tmp += 1
    return drec_k, rec_k, num_hsym


def get_hrmap():
    hrmaptxt = open('./hrmap.txt')
    first_tag = hrmaptxt.readline().split()
    SizeofSc, N_hrmap = int(first_tag[0]), int(first_tag[1])
    mapvec = np.zeros([6,N_hrmap])
    for ir in range(N_hrmap):
        line_str = hrmaptxt.readline().split()
        i1, i2, i3, i4, i5, i6 = int(line_str[0]), int(line_str[1]), int(line_str[2]),  int(line_str[3]),  int(line_str[4]), int(line_str[5])
        mapvec[0, ir] = i1
        mapvec[1, ir] = i2
        mapvec[2, ir] = i3
        mapvec[3, ir] = i4
        mapvec[4, ir] = i5
        mapvec[5, ir] = i6
    hrmaptxt.close()
    return mapvec, N_hrmap, SizeofSc


def do_wang_nac_correction(mapvec, N_hrmap, SizeofSc, epsilon, zstar, q, nat, R, Atom_Mass, cellvolume):
    nac_q = np.zeros([nat*3,nat*3]) 
    temp1 = np.dot(q, np.dot(epsilon,q.T))
    if (abs(q[0]**2 + q[1]**2 + q[2]**2) > 1.0e-5):
        constant_t= 4 * pi / (temp1 * cellvolume) * 14.39976 * VaspToTHz**2 
    else:
        constant_t= 0
    kBorn = np.zeros([nat,3])
    for i in range(nat):
        kBorn[i,:] = np.dot(q, zstar[i,:,:])
    for ii in range(nat):
        for jj in range(nat):
            tag = 0
            for s1 in range(N_hrmap):
                if (abs(mapvec[0,s1]-R[0])+abs(mapvec[1,s1]-R[1])+abs(mapvec[2,s1]-R[2])+abs(mapvec[3,s1]-ii-1)+abs(mapvec[4,s1]-jj-1)) < 1e-8:
                    for pp in range(3):
                        for qq in range(3):
                            nac_q[ii*3+pp,jj*3+qq] = kBorn[jj,qq] * kBorn[ii,pp] * constant_t / np.sqrt(Atom_Mass[ii]*Atom_Mass[jj]) / SizeofSc / mapvec[5,s1]
                            tag = 1
                else:
                    continue            
            if (tag == 0):
                for pp in range(3):
                    for qq in range(3):
                        nac_q[ii*3+pp,jj*3+qq] = 0
    return nac_q

def get_hr(name, scale): 
    hr = open('./{}_{}.{}'.format(name.split('.')[0],scale,name.split('.')[1]))
    hr.readline()
    nwan = int(hr.readline())
    nrpts = int(hr.readline())
    ndegen = np.zeros(nrpts)
    nrptsl = int(np.ceil(nrpts/15))
    for i in range(nrptsl-1):
        ndegen[i*15:i*15+15] = hr.readline().split()[:]
    ndegen[(nrptsl-1)*15:] = hr.readline().split()[:]
    HmnR = np.zeros([nwan,nwan,nrpts],dtype=complex)
    irvec = np.zeros([3,nrpts])
    for ir in range(nrpts):
        for i in range(nwan):
            for j in range(nwan):
                hmnrline = hr.readline().split()
                i1 = int(hmnrline[0])
                i2 = int(hmnrline[1])
                i3 = int(hmnrline[2])
                i4 = int(hmnrline[3])
                i5 = int(hmnrline[4])
                r1 = float(hmnrline[5])
                r2 = float(hmnrline[6])
                HmnR[i4-1,i5-1,ir] = complex(r1, r2)
        irvec[0, ir] = i1
        irvec[1, ir] = i2
        irvec[2, ir] = i3
    hr.close()
    return HmnR, irvec, ndegen

def hk_ph(scale, HmnR, irvec, ndegen, nac, K, nat, Atom_Mass, epsilon, zstar, A, cellvolume, mapvec, N_hrmap, SizeofSc): 
    nwan = len(HmnR)
    nrpts = len(irvec[0])
    omega = np.zeros([len(K),nwan])
    mode = np.zeros([len(K),nwan,nwan],dtype=complex)
    for iK in range(len(K)):
        Hamk = np.zeros([nwan,nwan],dtype=complex)
        vecm = np.zeros([nwan,nwan],dtype=complex)
        mode = np.zeros([nwan,nwan],dtype=complex)
        nac_correction = np.zeros([nwan,nwan],dtype=complex)
        for iR in range(nrpts):
            R = np.array(irvec[:,iR])
            kdotr = np.dot(K[iK],np.dot(R,A))
            if nac == 1:
                nac_correction = do_wang_nac_correction(mapvec, N_hrmap, SizeofSc, epsilon, zstar, K[iK], nat, R, Atom_Mass, cellvolume)
                if scale == 'cm1':
                    nac_correction = nac_correction * (THzToCm)**2 
            Hamk[:,:] += ( HmnR[:,:,iR] + nac_correction ) * np.exp(2.0*pi*zi*kdotr)/ndegen[iR]     
#           Hamk = impose_hermiticity(Hamk, nat)
        eig, vec = np.linalg.eigh(Hamk)
        for j in range(nwan):
            if eig[j]<0.0000001:
                omega[iK,j] = -1*np.sqrt(abs(eig[j]))
            else:
                omega[iK,j] = np.sqrt(abs(eig[j]))

    return omega 

