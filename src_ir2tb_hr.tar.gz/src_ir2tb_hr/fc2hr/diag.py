import numpy as np
import os
import sys
from numpy import pi, sqrt

################  CONSTANTS ################
###m_atom   = 1.66053906660E-27KG m_e  = 9.1093837015E-31KG amu_ry = 911.4442431086565   num/amu_ry = atom_unit
AMU_SI = 1.6605402e-27  #[kg]
ELECTRONMASS_SI  = 9.10938215e-31 
ELECTRONVOLT_SI  = 1.60217733e-19 #[J]
AMU_AU = AMU_SI / ELECTRONMASS_SI
AMU_RY = AMU_AU / 2.0   #amu_ry = 911.4442431086565
PlanckConstant = 4.13566733e-15   #[eV s]
Hbar = PlanckConstant / (2 * pi)  # [eV s]
H_PLANCK_EV = PlanckConstant * ELECTRONVOLT_SI
tpi = 2.0 * pi
fpi = 4.0 * pi
C_SI = 299792458  # [m/s]
Mu0 = 4.0e-7 * pi  # [Hartree/m]
Epsilon0 = 1.0 / Mu0 / C_SI**2  # [C^2 / N m^2]
HARTREE_EV = ELECTRONMASS_SI * ELECTRONVOLT_SI / 16 / pi**2 / Epsilon0**2 / Hbar**2  # Hartree [eV] 27.211398 
RYDBERG_EV = HARTREE_EV/2.0
AU_SEC = H_PLANCK_EV/tpi/HARTREE_EV
AU_PS = AU_SEC * 1.0e+12
AU_TERAHERTZ = AU_PS
RY_TO_THZ = 1.0 / AU_TERAHERTZ / fpi
RY_TO_CMM1 =1.0e+10 * RY_TO_THZ / C_SI
Angstrom = 1.0e-10  # [m]
BOHR_ANG =  4e10 * pi * Epsilon0 * Hbar**2 / ELECTRONMASS_SI  # Bohr radius [A] 0.5291772
BOHR_RADIUS_SI = BOHR_ANG * 1e-10
VaspToTHz = sqrt(ELECTRONVOLT_SI / AMU_SI) / Angstrom / (2 * pi) / 1e12  # [THz] 15.633302
THzToCm = 1.0e12 / (C_SI * 100)
zi = complex(0,1)
e2 = 2.0 
eps = 1.0e-6
################  CONSTANTS ################

################  ATOM DATA ################
atom_data = [
    [0, "X", "X", None],  # 0
    [1, "H", "Hydrogen", 1.00794],  # 1
    [2, "He", "Helium", 4.002602],  # 2
    [3, "Li", "Lithium", 6.941],  # 3
    [4, "Be", "Beryllium", 9.012182],  # 4
    [5, "B", "Boron", 10.811],  # 5
    [6, "C", "Carbon", 12.0107],  # 6
    [7, "N", "Nitrogen", 14.0067],  # 7
    [8, "O", "Oxygen", 15.9994],  # 8
    [9, "F", "Fluorine", 18.9984032],  # 9
    [10, "Ne", "Neon", 20.1797],  # 10
    [11, "Na", "Sodium", 22.98976928],  # 11
    [12, "Mg", "Magnesium", 24.3050],  # 12
    [13, "Al", "Aluminium", 26.9815386],  # 13
    [14, "Si", "Silicon", 28.0855],  # 14
    [15, "P", "Phosphorus", 30.973762],  # 15
    [16, "S", "Sulfur", 32.065],  # 16
    [17, "Cl", "Chlorine", 35.453],  # 17
    [18, "Ar", "Argon", 39.948],  # 18
    [19, "K", "Potassium", 39.0983],  # 19
    [20, "Ca", "Calcium", 40.078],  # 20
    [21, "Sc", "Scandium", 44.955912],  # 21
    [22, "Ti", "Titanium", 47.867],  # 22
    [23, "V", "Vanadium", 50.9415],  # 23
    [24, "Cr", "Chromium", 51.9961],  # 24
    [25, "Mn", "Manganese", 54.938045],  # 25
    [26, "Fe", "Iron", 55.845],  # 26
    [27, "Co", "Cobalt", 58.933195],  # 27
    [28, "Ni", "Nickel", 58.6934],  # 28
    [29, "Cu", "Copper", 63.546],  # 29
    [30, "Zn", "Zinc", 65.38],  # 30
    [31, "Ga", "Gallium", 69.723],  # 31
    [32, "Ge", "Germanium", 72.64],  # 32
    [33, "As", "Arsenic", 74.92160],  # 33
    [34, "Se", "Selenium", 78.96],  # 34
    [35, "Br", "Bromine", 79.904],  # 35
    [36, "Kr", "Krypton", 83.798],  # 36
    [37, "Rb", "Rubidium", 85.4678],  # 37
    [38, "Sr", "Strontium", 87.62],  # 38
    [39, "Y", "Yttrium", 88.90585],  # 39
    [40, "Zr", "Zirconium", 91.224],  # 40
    [41, "Nb", "Niobium", 92.90638],  # 41
    [42, "Mo", "Molybdenum", 95.96],  # 42
    [43, "Tc", "Technetium", None],  # 43
    [44, "Ru", "Ruthenium", 101.07],  # 44
    [45, "Rh", "Rhodium", 102.90550],  # 45
    [46, "Pd", "Palladium", 106.42],  # 46
    [47, "Ag", "Silver", 107.8682],  # 47
    [48, "Cd", "Cadmium", 112.411],  # 48
    [49, "In", "Indium", 114.818],  # 49
    [50, "Sn", "Tin", 118.710],  # 50
    [51, "Sb", "Antimony", 121.760],  # 51
    [52, "Te", "Tellurium", 127.60],  # 52
    [53, "I", "Iodine", 126.90447],  # 53
    [54, "Xe", "Xenon", 131.293],  # 54
    [55, "Cs", "Caesium", 132.9054519],  # 55
    [56, "Ba", "Barium", 137.327],  # 56
    [57, "La", "Lanthanum", 138.90547],  # 57
    [58, "Ce", "Cerium", 140.116],  # 58
    [59, "Pr", "Praseodymium", 140.90765],  # 59
    [60, "Nd", "Neodymium", 144.242],  # 60
    [61, "Pm", "Promethium", None],  # 61
    [62, "Sm", "Samarium", 150.36],  # 62
    [63, "Eu", "Europium", 151.964],  # 63
    [64, "Gd", "Gadolinium", 157.25],  # 64
    [65, "Tb", "Terbium", 158.92535],  # 65
    [66, "Dy", "Dysprosium", 162.500],  # 66
    [67, "Ho", "Holmium", 164.93032],  # 67
    [68, "Er", "Erbium", 167.259],  # 68
    [69, "Tm", "Thulium", 168.93421],  # 69
    [70, "Yb", "Ytterbium", 173.054],  # 70
    [71, "Lu", "Lutetium", 174.9668],  # 71
    [72, "Hf", "Hafnium", 178.49],  # 72
    [73, "Ta", "Tantalum", 180.94788],  # 73
    [74, "W", "Tungsten", 183.84],  # 74
    [75, "Re", "Rhenium", 186.207],  # 75
    [76, "Os", "Osmium", 190.23],  # 76
    [77, "Ir", "Iridium", 192.217],  # 77
    [78, "Pt", "Platinum", 195.084],  # 78
    [79, "Au", "Gold", 196.966569],  # 79
    [80, "Hg", "Mercury", 200.59],  # 80
    [81, "Tl", "Thallium", 204.3833],  # 81
    [82, "Pb", "Lead", 207.2],  # 82
    [83, "Bi", "Bismuth", 208.98040],  # 83
    [84, "Po", "Polonium", None],  # 84
    [85, "At", "Astatine", None],  # 85
    [86, "Rn", "Radon", None],  # 86
    [87, "Fr", "Francium", None],  # 87
    [88, "Ra", "Radium", None],  # 88
    [89, "Ac", "Actinium", None],  # 89
    [90, "Th", "Thorium", 232.03806],  # 90
    [91, "Pa", "Protactinium", 231.03588],  # 91
    [92, "U", "Uranium", 238.02891],  # 92
    [93, "Np", "Neptunium", None],  # 93
    [94, "Pu", "Plutonium", None],  # 94
    [95, "Am", "Americium", None],  # 95
    [96, "Cm", "Curium", None],  # 96
    [97, "Bk", "Berkelium", None],  # 97
    [98, "Cf", "Californium", None],  # 98
    [99, "Es", "Einsteinium", None],  # 99
    [100, "Fm", "Fermium", None],  # 100
    [101, "Md", "Mendelevium", None],  # 101
    [102, "No", "Nobelium", None],  # 102
    [103, "Lr", "Lawrencium", None],  # 103
    [104, "Rf", "Rutherfordium", None],  # 104
    [105, "Db", "Dubnium", None],  # 105
    [106, "Sg", "Seaborgium", None],  # 106
    [107, "Bh", "Bohrium", None],  # 107
    [108, "Hs", "Hassium", None],  # 108
    [109, "Mt", "Meitnerium", None],  # 109
    [110, "Ds", "Darmstadtium", None],  # 110
    [111, "Rg", "Roentgenium", None],  # 111
    [112, "Cn", "Copernicium", None],  # 112
    [113, "Uut", "Ununtrium", None],  # 113
    [114, "Uuq", "Ununquadium", None],  # 114
    [115, "Uup", "Ununpentium", None],  # 115
    [116, "Uuh", "Ununhexium", None],  # 116
    [117, "Uus", "Ununseptium", None],  # 117
    [118, "Uuo", "Ununoctium", None],  # 118
]
################  ATOM DATA ################

def CellVolume(A, celldm1):
    #cellvolume1 = np.dot(A[0], np.cross(A[1], A[2])) * (float(celldm1)*BOHR_ANG)**3
    cellvolume2 = np.linalg.det(A) * (celldm1*BOHR_ANG)**3
    return cellvolume2


def read_kpts(kpts_name,B):
    if os.path.exists('./{}'.format(kpts_name)) is not True :
        print("ERROR: We need qe.kpts !!!")
        exit(0)
    
    kpts = open('./{}'.format(kpts_name))
    num_hsym = int(kpts.readline().split()[0])
    hsym_p = np.zeros([num_hsym,4])
    for i in range(num_hsym):
        hsym_p[i,:] = kpts.readline().split()[:]
        hsym_p[i,0:3] = np.dot(hsym_p[i,0:3],B)
    kpts.close()
    hsym_p[-1,3] = 1
    nk = sum(hsym_p[:,3])
    rec_k = np.zeros([int(nk),3])
    drec_k = np.zeros([int(nk)])
    tmp = 0
    tmp1 = 0
    for i in range(num_hsym):
        if i < num_hsym-1 :
            diff = hsym_p[i+1,0:3] - hsym_p[i,0:3]
        else:
            diff = np.zeros([1,3])
        for j in range(int(hsym_p[i,3])):
            rec_k[tmp,:] = hsym_p[i,0:3] + diff * j / hsym_p[i,3]      ##klist(a,b,c)
            drec_k[tmp] = tmp1         ##kpath
            tmp1 += np.linalg.norm(diff / hsym_p[i,3] ) 
            tmp += 1
    return drec_k, rec_k, num_hsym


def get_hrmap():
    hrmaptxt = open('./hrmap.txt')
    first_tag = hrmaptxt.readline().split()
    SizeofSc, N_hrmap = int(first_tag[0]), int(first_tag[1])
    mapvec = np.zeros([6,N_hrmap])
    for ir in range(N_hrmap):
        line_str = hrmaptxt.readline().split()
        i1, i2, i3, i4, i5, i6 = int(line_str[0]), int(line_str[1]), int(line_str[2]),  int(line_str[3]),  int(line_str[4]), int(line_str[5])
        mapvec[0, ir] = i1
        mapvec[1, ir] = i2
        mapvec[2, ir] = i3
        mapvec[3, ir] = i4
        mapvec[4, ir] = i5
        mapvec[5, ir] = i6
    hrmaptxt.close()
    return mapvec, N_hrmap, SizeofSc


def do_wang_nac_correction(mapvec, N_hrmap, SizeofSc, epsilon, zstar, q, nat, R, Atom_Mass, cellvolume):
    nac_q = np.zeros([nat*3,nat*3]) 
    temp1 = np.dot(q, np.dot(epsilon,q.T))
    if (abs(q[0]**2 + q[1]**2 + q[2]**2) > 1.0e-5):
        constant_t= 4 * pi / (temp1 * cellvolume) * 14.39976 * VaspToTHz**2 
    else:
        constant_t= 0
    kBorn = np.zeros([nat,3])
    for i in range(nat):
        kBorn[i,:] = np.dot(q, zstar[i,:,:])
    for ii in range(nat):
        for jj in range(nat):
            tag = 0
            for s1 in range(N_hrmap):
                if (abs(mapvec[0,s1]-R[0])+abs(mapvec[1,s1]-R[1])+abs(mapvec[2,s1]-R[2])+abs(mapvec[3,s1]-ii-1)+abs(mapvec[4,s1]-jj-1)) < 1e-8:
                    for pp in range(3):
                        for qq in range(3):
                            nac_q[ii*3+pp,jj*3+qq] = kBorn[jj,qq] * kBorn[ii,pp] * constant_t / np.sqrt(Atom_Mass[ii]*Atom_Mass[jj]) / SizeofSc / mapvec[5,s1]
                            tag = 1
                else:
                    continue            
            if (tag == 0):
                for pp in range(3):
                    for qq in range(3):
                        nac_q[ii*3+pp,jj*3+qq] = 0
    return nac_q

def get_hr(name, scale): 
    hr = open('./{}_{}.{}'.format(name.split('.')[0],scale,name.split('.')[1]))
    hr.readline()
    nwan = int(hr.readline())
    nrpts = int(hr.readline())
    ndegen = np.zeros(nrpts)
    nrptsl = int(np.ceil(nrpts/15))
    for i in range(nrptsl-1):
        ndegen[i*15:i*15+15] = hr.readline().split()[:]
    ndegen[(nrptsl-1)*15:] = hr.readline().split()[:]
    HmnR = np.zeros([nwan,nwan,nrpts],dtype=complex)
    irvec = np.zeros([3,nrpts])
    for ir in range(nrpts):
        for i in range(nwan):
            for j in range(nwan):
                hmnrline = hr.readline().split()
                i1 = int(hmnrline[0])
                i2 = int(hmnrline[1])
                i3 = int(hmnrline[2])
                i4 = int(hmnrline[3])
                i5 = int(hmnrline[4])
                r1 = float(hmnrline[5])
                r2 = float(hmnrline[6])
                HmnR[i4-1,i5-1,ir] = complex(r1, r2)
        irvec[0, ir] = i1
        irvec[1, ir] = i2
        irvec[2, ir] = i3
    hr.close()
    return HmnR, irvec, ndegen

def hk_ph(scale, HmnR, irvec, ndegen, nac, K, nat, Atom_Mass, epsilon, zstar, A, cellvolume, mapvec, N_hrmap, SizeofSc): 
    nwan = len(HmnR)
    nrpts = len(irvec[0])
    omega = np.zeros([len(K),nwan])
    mode = np.zeros([len(K),nwan,nwan],dtype=complex)
    for iK in range(len(K)):
        Hamk = np.zeros([nwan,nwan],dtype=complex)
        vecm = np.zeros([nwan,nwan],dtype=complex)
        mode = np.zeros([nwan,nwan],dtype=complex)
        nac_correction = np.zeros([nwan,nwan],dtype=complex)
        for iR in range(nrpts):
            R = np.array(irvec[:,iR])
            kdotr = np.dot(K[iK],np.dot(R,A))
            if nac == 1:
                nac_correction = do_wang_nac_correction(mapvec, N_hrmap, SizeofSc, epsilon, zstar, K[iK], nat, R, Atom_Mass, cellvolume)
                if scale == 'cm1':
                    nac_correction = nac_correction * (THzToCm)**2 
            Hamk[:,:] += ( HmnR[:,:,iR] + nac_correction ) * np.exp(2.0*pi*zi*kdotr)/ndegen[iR]     
#           Hamk = impose_hermiticity(Hamk, nat)
        eig, vec = np.linalg.eigh(Hamk)
        for j in range(nwan):
            if eig[j]<0.0000001:
                omega[iK,j] = -1*np.sqrt(abs(eig[j]))
            else:
                omega[iK,j] = np.sqrt(abs(eig[j]))

    return omega 



if os.path.exists('./ph.fc') is not True :
    print("ERROR: We need ph.fc !!!")
    exit(0)
k = open('./ph.fc')
fi = k.readline().split()
ntyp = int(fi[0])
nat = int(fi[1])
celldm1 = float(fi[3])
A = np.zeros([3,3])
for i in range(3):
    ll = k.readline().split()
    for j in range(3):
        A[i][j] = ll[j]
mass_type = np.zeros([ntyp,2],dtype=object)
Atom_Mass = np.zeros(nat)
tau = np.zeros([nat,3])
for i in range(ntyp):
    ll = k.readline().split()
    mass_type[i,0] = ll[0]
    mass_type[i,1] = ll[1].split("'")[1]
for n in range(len(atom_data)):
    for i in range(ntyp):
        if atom_data[n][1] == mass_type[i,1]:
            mass_type[i,1] = atom_data[n][3]
for i in range(nat):
    ll = k.readline().split()
    for j in range(ntyp):
        if float(ll[1]) == float(mass_type[j][0]):
            Atom_Mass[i] = mass_type[j,1]
    tau[i,:] = np.array([float(val) for val in ll[2:5]])
epsil = k.readline().split()
k.close()

epsilon = np.zeros([3,3])
zstar = np.zeros([nat,3,3])
nac = 0
if len(sys.argv) > 1:
    if sys.argv[1] == '1':
        if epsil[0] == "T":
            print('If you want to add NAC, please remove the dielectric constant and Born effective charges data from the Gamma point dyn file and run q2r.x again to get correct ph.fc!!!')
            exit()
        else:
            if os.path.exists('./allborn') is not True :
                print("Cannot find allborn file, TO-LO splitting at q=0 will be absent!!!")
            else:
                nac = 1
                allborn = open('./allborn')
                for i in range(3):
                    epsilon[i,:] = allborn.readline().split()
                for i in range(nat):
                    allborn.readline()
                    zstar[i,0,:] = allborn.readline().split()
                    zstar[i,1,:] = allborn.readline().split()
                    zstar[i,2,:] = allborn.readline().split()
                allborn.close()
B = np.transpose(np.linalg.inv(A))

drec_k, rec_k, num_hsym = read_kpts('qe.kpts',B)
cellvolume = CellVolume(A,celldm1)


scale = 'cm1'
####phhr_cm1.dat####
HmnR, irvec, ndegen = get_hr('phhr.dat',scale)
if nac == 1:
    mapvec, N_hrmap, SizeofSc = get_hrmap() 
else:
    mapvec, N_hrmap, SizeofSc = 0,0,0
omega=hk_ph(scale, HmnR, irvec, ndegen, nac, rec_k, nat, Atom_Mass, epsilon, zstar, A, cellvolume, mapvec, N_hrmap, SizeofSc)

f=open('./freq','w')
for i in range(len(rec_k)):
    print('{:10.6f}   '.format(drec_k[i]),end='',file=f)
    for j in range(3*nat):
        print('{:10.4f}'.format(omega[i,j]),end='' ,file=f)
    print(end='\n',file=f)
f.close()





