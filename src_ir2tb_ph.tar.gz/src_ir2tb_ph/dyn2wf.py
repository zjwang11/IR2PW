import numpy as np
import os
import sys



nks = int(sys.argv[1])
fcnat = int(os.popen('grep "freq" ./q0.dyn |wc -l').read())//3
u = np.zeros([nks,3*fcnat,6*fcnat])
fr = np.zeros([nks,3*fcnat,1])
for i in range(nks):
    iq=str(i)
    data = os.popen("sed -n '/Diagonalizing/,$'p ./q"+iq+".dyn").readlines()
    for j in range(3*fcnat):
        fr[i][j][0] = float(data[5+(fcnat+1)*j].split("=")[1].split()[0])
        for k in range(fcnat):
            for l in range(6):
                    u[i][j][k*6+l] = float(data[6+(fcnat+1)*j+k].split()[l+1])


pfile = open('./ph_wf.dat','w')

print('{:8d}{:8d}{:8d}'.format(nks,3*fcnat,3*fcnat),file=pfile)
for i in range(nks):
    for j in range(3*fcnat):
        print('{:13.6f}'.format(fr[i][j][0]),file=pfile)
        
        for kk in range((3*fcnat)//3):
            xxx = (kk+1)*3
            for kkk in range(xxx-3, xxx):
                print("{:12.6f}{:12.6f}".format(u[i][j][2*kkk],u[i][j][2*kkk+1]), end='',file=pfile)
            print(' ',file=pfile)
        if 3*fcnat % 3 > 0:
            for k in range(xxx, xxx+(3*fcnat)%3):
                print("{:12.6f}{:12.6f}".format(u[i][j][2*k],u[i][j][2*k+1]), end='',file=pfile)
            print(' ',file=pfile)
pfile.close()





